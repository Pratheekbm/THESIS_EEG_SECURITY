All figures produced by matplotlib, a python plotting library.
More info at matplotlib.sourceforge.net/

These plots taken from http://matplotlib.sourceforge.net/gallery.html
